import React from 'react'

export default function Total({part1,part2,part3}) {
    return (
        <div>
            <p>Number of exercises {part1.exercises + part2.exercises  + part2.exercises}</p>
        </div>
    )
}
