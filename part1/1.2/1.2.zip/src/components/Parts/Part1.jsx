import React from 'react'

export default function Part1(props) {
    return (
        <div>
              <p>
        {props.part1} {props.exercises1}
      </p>
        </div>
    )
}
