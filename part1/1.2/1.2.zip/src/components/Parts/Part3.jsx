import React from 'react'

export default function Part3(props) {
    return (
        <div>
           <p>{props.part3}</p> 
        </div>
    )
}
