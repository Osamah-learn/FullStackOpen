import React from "react";

export default function Part({data}) {
  
  return (
    <div>
    <p>{data.name}</p>
    </div>
  );
}
