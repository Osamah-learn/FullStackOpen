import React from 'react'

export default function Part2(props) {
    return (
        <div>
            {props.part2} {props.exercises2}
        </div>
    )
}
