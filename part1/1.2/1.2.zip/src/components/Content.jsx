import React from "react";
import Part1 from "./Parts/Part1";
import Part2 from "./Parts/Part2";
import Part3 from "./Parts/Part3";
export default function Content(props) {
  return (
    <div>
      <Part1 part1={props.part1} exercises1={props.exercises1} />

      <Part2 part2={props.part2} exercises2={props.exercises2} />
      <Part3 part3={props.part3}/>
    </div>
  );
}
